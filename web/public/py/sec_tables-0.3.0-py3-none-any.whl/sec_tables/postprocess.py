"""Turn a raw grid into one row per executive-year.

Three artefacts of how filings are typeset, each of which corrupts the output if
left alone:

1. **Currency marker columns.** Filers put "$" in its own cell and the amount in
   the next, so every money column arrives as a pair and the header maps both to
   the same role — `salary`, `salary_2`. The marker half is always empty after
   numeric normalization, so it can be identified and folded away.

2. **Blank spacer rows.** Used for vertical rhythm. They carry no data and would
   otherwise become rows of empty strings.

3. **Stacked name/title blocks.** This is the substantive one. The SCT layout is
   one row per fiscal year, with the executive's name on the first of those rows
   and their title continuing on the rows beneath it:

       Roy C. Harvey             2022   1,148,333 ...
       President and             2021   1,095,333 ...
       Chief Executive Officer   2020   1,055,583 ...

   Read naively that is three different people, one of whom is named "President
   and". The name must be carried down across the year rows and the title
   accumulated separately.
"""
from __future__ import annotations

import re

from .types import Assembly, Table

# Words that mark a cell as a job title rather than a person's name. Checked
# before name shape, because "Chief Executive Officer" is capitalised like one.
#
# Matched on WORD BOUNDARIES, not as substrings. Substring matching silently
# reclassified real executives as titles — "and" occurs inside Alexander,
# Anderson, Sandra, Chandler and Alessandro — which attributed their pay rows to
# whoever preceded them in the table. "and" is therefore absent entirely: every
# title fragment containing it ("President and", "and Chief Executive Officer")
# is already caught by a substantive word.
_TITLE_WORDS = (
    "president", "chief", "officer", "cfo", "ceo", "coo", "cto", "cao", "cio",
    "evp", "svp", "vp", "vice", "executive", "chairman", "chairwoman", "chair",
    "director", "treasurer", "secretary", "counsel", "controller", "principal",
    "manager", "managing", "partner", "founder", "senior", "division",
    "general", "interim", "former", "operations", "financial", "finance",
    "legal", "accounting", "administrative", "commercial", "technology",
    "marketing", "officers", "employee", "head",
)
_TITLE_RE = re.compile(r"\b(?:" + "|".join(_TITLE_WORDS) + r")\b", re.IGNORECASE)

# A trailing comma may appear *inside* the sequence, not only at the end:
# "Thomas J. Roeck, Jr" puts one before the generational suffix. Requiring the
# comma only at the end rejects every such name and silently attributes their
# compensation rows to the previous executive.
_NAME_WORD = r"(?:[A-Z]\.|[A-Z][A-Za-z'’\-]+|van|von|der|de|del|da|di|la|le|Jr\.?|Sr\.?|II|III|IV|V)"
_NAME_RE = re.compile(rf"^(?:[A-Z]\.\s*)*[A-Z][A-Za-z'’\-]+,?(?:\s+{_NAME_WORD},?)*[.]?$")
_YEAR_RE = re.compile(r"^(?:19|20)\d{2}$")
_FOOTNOTE_TAIL = re.compile(r"\s*\((?:[0-9]{1,3}|[a-z])\)\s*$")
# Professional credentials trail a name and are not part of its shape.
# "Avadis Tevanian, Jr. Ph.D" failed the name test on "Ph.D", so no new
# person block opened and his rows inherited the previous executive's name.
_CREDENTIAL_TAIL = re.compile(
    r",?\s*(?:Ph\.?\s?D|M\.?\s?D|J\.?\s?D|M\.?B\.?A|C\.?P\.?A|Ed\.?\s?D|Esq|MBA|CFA)\.?\s*$",
    re.IGNORECASE,
)
_TEXT_ROLES = frozenset({
    "name", "position", "name_and_position", "year", "holder_name",
    "holder_address", "share_class", "section", "is_group", "unknown",
})


def looks_like_title(text: str) -> bool:
    s = text.strip(" ,.")
    if not s:
        return False
    return bool(_TITLE_RE.search(s))


def looks_like_person(text: str) -> bool:
    # Credentials are stripped for the SHAPE test only; the caller keeps them in
    # the name it emits, because that is how the filing lists the person.
    s = _CREDENTIAL_TAIL.sub("", _FOOTNOTE_TAIL.sub("", text)).strip()
    if not s or len(s) < 3:
        return False
    if looks_like_title(s):
        return False
    words = s.split()
    if not (1 < len(words) <= 6):
        return False
    return bool(_NAME_RE.match(s))


def split_name_title(cell: str) -> tuple[str, str]:
    """Separate a person's name from a title packed into the same cell.

    Filings combine them three ways:
      "Roy C. Harvey<br>President and CEO"     -> a line break
      "D. Christian Koch, Chair, President"    -> a comma
      "Michael P. McMasters (7) Chief Exec..." -> a footnote marker

    Returns (name, title); title is empty when the cell holds only a name.
    """
    text = cell.strip()
    if not text:
        return "", ""

    if "\n" in text:
        head, *rest = [p.strip() for p in text.split("\n") if p.strip()]
        tail = " ".join(rest)
        # A <br> inside this cell means one of two different things, and guessing
        # wrong is silent: "Roy C. Harvey<br>President and CEO" is name-then-title,
        # but "Richard<br>P. Dealy" is a single name wrapped for column width.
        # Treating the second as name-then-title yields a director called
        # "Richard" and sweeps every later name into the title field.
        if tail and looks_like_title(tail):
            return _clean_name(head), tail
        joined = f"{head} {tail}".strip()
        if looks_like_person(joined):
            return _clean_name(joined), ""
        return _clean_name(head), tail

    # A footnote marker often sits exactly at the name/title seam.
    m = re.search(r"\((?:\d{1,3}|[a-z])\)\s*(?=\S)", text)
    if m and looks_like_title(text[m.end():]):
        return _clean_name(text[: m.start()]), text[m.end():].strip()

    # Try each comma as a seam, preferring the earliest that splits cleanly.
    for m in re.finditer(r",\s*", text):
        left, right = text[: m.start()], text[m.end():]
        if not right:
            continue
        if looks_like_person(left) and looks_like_title(right):
            return _clean_name(left), right.strip()

    # No punctuation seam, but a title still starts somewhere: filings often run
    # the two together with no separator at all — "Tim Cook Chief Executive
    # Officer". Treating that whole cell as a title (because it contains title
    # words) loses the executive's name entirely and leaves the row anonymous.
    # The first title word is the seam.
    m = _TITLE_RE.search(text)
    if m and m.start() > 0:
        head, tail = text[: m.start()].strip(" ,"), text[m.start():].strip()
        if head and looks_like_person(head):
            return _clean_name(head), tail

    # A cell that is title from its first word is a continuation line, not a name.
    if looks_like_title(text) and not looks_like_person(text):
        return "", text
    return _clean_name(text), ""


def _clean_name(text: str) -> str:
    return _FOOTNOTE_TAIL.sub("", text).strip().rstrip(",").strip()


def _role_index(roles: list[str], want: str) -> int | None:
    for i, r in enumerate(roles):
        if r == want:
            return i
    return None


def merge_marker_columns(table: Table) -> Table:
    """Fold `$`-marker columns into the value column they precede."""
    roles, header, rows = list(table.roles), list(table.header), [list(r) for r in table.rows]

    def base(role: str) -> str:
        return role.rsplit("_", 1)[0] if role[-1:].isdigit() else role

    drop: set[int] = set()
    for i, role in enumerate(roles):
        if not role[-1:].isdigit():
            continue
        b = base(role)
        j = _role_index(roles, b)
        if j is None or j in drop:
            continue
        col_j = [(r[j] if j < len(r) else "") for r in rows]
        col_i = [(r[i] if i < len(r) else "") for r in rows]
        j_empty = all(not v.strip() for v in col_j)
        i_empty = all(not v.strip() for v in col_i)
        if j_empty and not i_empty:
            drop.add(j)
            roles[i] = b
        elif i_empty and not j_empty:
            drop.add(i)

    keep = [i for i in range(len(roles)) if i not in drop]
    return Table(
        header=[header[i] for i in keep if i < len(header)],
        rows=[[(r[i] if i < len(r) else "") for i in keep] for r in rows],
        roles=[roles[i] for i in keep],
    )


_MARKER_VALUE = re.compile(
    r"^(?:\((?:\d{1,3}|[a-z])\)|[%$*†‡()]|\(\d{1,3}\)\s*\(\d{1,3}\))$"
)


def drop_marker_columns(table: Table) -> Table:
    """Drop columns that carry only footnote references or a lone symbol.

    Filings put footnote markers and the "%" sign in their own cells, so a
    two-column pair arrives as (value, "(3)") or (value, "%"). These are
    typography, not data. Only unnamed columns qualify — a column with a real
    header is kept even if its values look marker-like, since dropping a named
    column would silently lose a field.
    """
    roles, header, rows = list(table.roles), list(table.header), table.rows
    if not rows:
        return table

    drop: set[int] = set()
    for i, role in enumerate(roles):
        named = role != "unknown" and not role.startswith("unknown")
        if named:
            continue
        values = [(r[i] if i < len(r) else "").strip() for r in rows]
        present = [v for v in values if v]
        if present and all(_MARKER_VALUE.match(v) for v in present):
            drop.add(i)

    if not drop:
        return table
    keep = [i for i in range(len(roles)) if i not in drop]
    return Table(
        header=[header[i] for i in keep if i < len(header)],
        rows=[[(r[i] if i < len(r) else "") for i in keep] for r in rows],
        roles=[roles[i] for i in keep],
    )


def drop_empty_value_columns(table: Table) -> Table:
    """Drop suffixed duplicate roles that ended up entirely empty.

    `merge_marker_columns` only folds a pair when exactly one side is empty; a
    header split three ways across colspans can leave two empty siblings.
    """
    roles, header, rows = list(table.roles), list(table.header), table.rows
    if not rows:
        return table
    drop = {
        i for i, role in enumerate(roles)
        if role[-1:].isdigit()
        and not any((r[i] if i < len(r) else "").strip() for r in rows)
    }
    if not drop:
        return table
    keep = [i for i in range(len(roles)) if i not in drop]
    return Table(
        header=[header[i] for i in keep if i < len(header)],
        rows=[[(r[i] if i < len(r) else "") for i in keep] for r in rows],
        roles=[roles[i] for i in keep],
    )


_PERCENT_VALUE = re.compile(r"^\s*\(?\d{1,3}(?:\.\d+)?\s*%\s*\)?$")


def repair_roles_by_values(table: Table) -> Table:
    """Correct a column's role from what it CONTAINS when the header misleads.

    Header text is not always sufficient. An Item 403 percentage column headed
    only "Class*" — because "Percent of" wrapped onto a line that merged
    elsewhere — reads as a share class, so its values keep their "%" and are
    never numerically normalised.

    A column whose values are all percentages is a percentage. This only ever
    *renames* a column, never moves data, so a wrong guess is visible rather
    than corrupting.
    """
    roles = list(table.roles)
    if not table.rows:
        return table

    changed = False
    for i, role in enumerate(roles):
        base = role.rsplit("_", 1)[0] if role[-1:].isdigit() else role
        if base == "percent":
            continue
        values = [(r[i] if i < len(r) else "").strip() for r in table.rows]
        present = [v for v in values if v]
        if len(present) >= 2 and all(_PERCENT_VALUE.match(v) for v in present):
            roles[i] = "percent" if "percent" not in roles else f"percent_{i}"
            changed = True

    if not changed:
        return table
    return Table(header=table.header, rows=table.rows, roles=roles)


def explode_stacked_rows(table: Table) -> Table:
    """Split rows whose cells stack several fiscal years into one row each.

    Early-2000s HTML filings lay the SCT out as ONE row per executive, with the
    three reported years stacked inside every cell by <br>:

        Steven P. Jobs        2002        1        2,268,698
        Chief Executive       2001        1       43,511,534
        Officer               2000        1

    Read as written that is one row per person with unusable multi-value cells —
    Apple 2003 produced 5 rows instead of 15, with three years crushed into one
    field. The year column states how many rows the line really is.

    The identity column is NOT split: its line break separates name from title,
    not one year from the next.
    """
    roles = list(table.roles)
    year_i = _role_index(roles, "year")
    if year_i is None:
        return table

    name_i = _role_index(roles, "name_and_position")
    if name_i is None:
        name_i = _role_index(roles, "name")

    out: list[list[str]] = []
    changed = False
    for row in table.rows:
        years = [y for y in (row[year_i] if year_i < len(row) else "").split("\n")]
        n = len(years)
        if n <= 1:
            out.append(row)
            continue
        changed = True
        for k in range(n):
            new: list[str] = []
            for i, cell in enumerate(row):
                if i == name_i:
                    new.append(cell)          # name/title, repeated as-is
                    continue
                parts = cell.split("\n")
                # A single value applies to every year; a matching count maps
                # positionally; anything else is padded rather than guessed at.
                if len(parts) == 1:
                    new.append(parts[0] if i != year_i else years[k])
                elif len(parts) == n:
                    new.append(parts[k])
                else:
                    new.append(parts[k] if k < len(parts) else "")
            out.append(new)

    if not changed:
        return table
    return Table(header=table.header, rows=out, roles=roles)


def drop_blank_rows(table: Table) -> Table:
    rows = [r for r in table.rows if any(v.strip() for v in r)]
    return Table(header=table.header, rows=rows, roles=table.roles)


def assemble_people(table: Table) -> Table:
    """Collapse stacked name/title blocks into one row per person-year.

    Emits explicit `name` and `position` columns in place of the combined
    `name_and_position` column, since downstream panel work keys on the name.
    """
    roles = list(table.roles)
    # Index 0 is falsy, so `a or b` would discard a name column in the first
    # position — which is where it always is.
    name_i = _role_index(roles, "name_and_position")
    if name_i is None:
        name_i = _role_index(roles, "name")
    year_i = _role_index(roles, "year")
    if name_i is None:
        return table

    # Not every person-shaped table has a year. Item 402(r) director compensation
    # is one row per director for a single fiscal year, so there is no year column
    # to trigger on — fall back to "this row carries numbers". Same stacked
    # name/title problem, same solution, different emit condition.
    value_idx = [
        i for i, r in enumerate(roles)
        if i != name_i
        and r.rsplit("_", 1)[0] not in _TEXT_ROLES
        and r not in _TEXT_ROLES
    ]

    out_roles = ["name", "position"] + [r for i, r in enumerate(roles) if i not in (name_i,)]
    out_rows: list[list[str]] = []

    # Buffer each person's block before emitting. A title's final fragment can
    # appear on a line *after* that person's last year row ("and Chief Executive
    # Officer" trailing the 1995 row), so emitting eagerly would stamp every row
    # with a title that is still being built.
    current_name = ""
    title_parts: list[str] = []
    pending: list[list[str]] = []
    saw_year_for_current = False

    def flush() -> None:
        title = " ".join(title_parts)
        for buffered in pending:
            buffered[1] = title
        out_rows.extend(pending)
        pending.clear()

    for row in table.rows:
        cell = (row[name_i] if name_i < len(row) else "").strip()
        if year_i is not None:
            year = (row[year_i] if year_i < len(row) else "").strip()
            has_data = bool(_YEAR_RE.match(year))
        else:
            has_data = any((row[i] if i < len(row) else "").strip() for i in value_idx)

        if cell:
            cell_name, cell_title = split_name_title(cell)
            # `split_name_title` returns the whole cell as the name when it finds
            # no seam, so the person test still gates starting a new block —
            # otherwise a wrapped parenthetical ("(retired", "effective July 31,
            # 1997)") would open one.
            if cell_name and looks_like_person(cell_name) and (saw_year_for_current or not current_name):
                flush()
                current_name = cell_name
                title_parts = [cell_title] if cell_title else []
                saw_year_for_current = False
            elif current_name:
                for piece in (cell_title, cell_name):
                    if piece and piece not in title_parts:
                        title_parts.append(piece)
            elif cell_name:
                current_name = cell_name
                if cell_title:
                    title_parts.append(cell_title)

        if not has_data:
            continue

        saw_year_for_current = True
        rest = [(row[i] if i < len(row) else "") for i in range(len(roles)) if i != name_i]
        pending.append([current_name, "", *rest])

    flush()

    if not out_rows:
        return table

    out_header = ["Name", "Position"] + [
        (table.header[i] if i < len(table.header) else "")
        for i in range(len(roles)) if i != name_i
    ]
    return Table(header=out_header, rows=out_rows, roles=out_roles)


_SECTION_LABEL = re.compile(r":\s*$")
_GROUP_PHRASES = (
    "as a group", "all directors", "all executive officers",
    "named executive officers", "all officers",
)


def looks_like_group_row(text: str) -> bool:
    """A subtotal row ("All directors and executive officers as a group").

    These are real Item 403 disclosures, not noise, but they are aggregates and
    must be distinguishable from individual holders or any concentration measure
    computed downstream will double-count.
    """
    low = text.lower()
    return any(p in low for p in _GROUP_PHRASES)


_ADDRESS_HINT = re.compile(
    # A house number followed by a word — "55 East", "100 Vanguard". Written
    # WITHOUT a trailing \b: `\d+\s+\w\b` only matches when the following word is
    # a single character, so "55 East" never matched and the seam fell through to
    # the later "Street", cutting the address in half and leaving a holder called
    # "BlackRock, Inc. 55 East 52 nd".
    r"(?:\b\d{1,6}\s+[A-Za-z]"
    r"|\b(?:street|avenue|ave|road|boulevard|blvd|suite|floor|drive|lane|"
    r"plaza|parkway|way|centre|center|tower|building)\b"
    r"|\bp\.?\s*o\.?\s*box\b"
    r"|\b[A-Z]{2}\s+\d{5}\b)",
    re.IGNORECASE,
)


def _split_holder_address(cell: str) -> tuple[str, str]:
    """Separate a holder name from an address in the same cell.

    Item 403 mandates "Name and Address of Beneficial Owner" as one column, so
    institutional holders arrive as "BlackRock, Inc.<br>55 East 52nd Street<br>
    New York, NY 10055". The name is the first line; everything after it that
    looks like an address is the address.
    """
    # Flatten line breaks BEFORE looking for the seam. A filer may wrap this cell
    # anywhere: "BlackRock, Inc.<br>55 East 52nd Street" breaks between name and
    # address, but "BlackRock, Inc. 55 East 52nd<br>Street New York, NY" breaks
    # mid-address. Splitting on the first break gets the second case wrong and
    # produces a holder named "BlackRock, Inc. 55 East 52 nd". Where the address
    # *starts* is a content question, not a typography one.
    text = " ".join(cell.split())
    if not text:
        return "", ""
    m = _ADDRESS_HINT.search(text)
    if m and m.start() > 0:
        return text[: m.start()].strip(" ,"), text[m.start():].strip()
    # No address signal at all: fall back to the line break, if there was one.
    if "\n" in cell:
        head, *rest = [p.strip() for p in cell.split("\n") if p.strip()]
        return head, " ".join(rest)
    return text, ""


_PROSE_HINT = re.compile(
    r"\b(?:pursuant|schedule 13[gd]|securities and exchange|filed|statement|"
    r"reported|according to|includes?|represents?|consists?)\b",
    re.IGNORECASE,
)


def looks_like_address(text: str) -> bool:
    """Whether an identity value is really a street address.

    Plain-text ownership tables put the holder's address on its own line, and
    when the column geometry drifts those lines surface as separate holders —
    "82 Devonshire Street Boston, MA" appearing alongside real institutions.
    """
    t = text.strip()
    if not t:
        return False
    if re.match(r"^\d{1,6}\s+[A-Za-z]", t):      # opens with a house number
        return True
    m = _ADDRESS_HINT.search(t)
    return bool(m and m.start() == 0)


def looks_like_prose(text: str) -> bool:
    """Footnote text leaking into an identity column.

    Judged on prose markers alone, not length. Legitimate institutional holders
    are routinely long — "Neuberger Berman Group LLC Neuberger Berman Investment
    Advisers LLC Neuberger Berman Equity Funds" is one disclosed holder, and a
    word-count rule flags it as broken.
    """
    return bool(_PROSE_HINT.search(text))


def suspect_identities(table: Table, identity_role: str) -> list[str]:
    """Identity values that are not plausibly names of holders.

    Returned rather than silently repaired: the correct owner of a misaligned
    row is genuinely ambiguous, and inventing one would replace a visible defect
    with an invisible one.
    """
    if identity_role not in table.roles:
        return []
    i = table.roles.index(identity_role)
    bad = []
    for row in table.rows:
        v = (row[i] if i < len(row) else "").strip()
        if v and (looks_like_address(v) or looks_like_prose(v)):
            bad.append(v)
    return bad


def assemble_holders(table: Table) -> Table:
    """Collapse an ownership table to one row per beneficial holder.

    Different shape from a compensation table: no year, one row per holder, and
    both the name and the address wrap over continuation lines.

    The subtlety is WHICH holder a continuation line belongs to. In a plain-text
    Item 403 table the share count and percentage appear only on a holder's first
    line, and everything below it — the rest of the name, then the address —
    belongs to that holder:

        Common Stock   FMR Corp.(1)                  13,552,054   12.8%
                        82 Devonshire Street
                        Boston, MA  02109
        Common Stock   Brinson Partners, Inc.(2)      6,904,354    6.5%

    Buffering those lines and attaching them to the *next* holder — the obvious
    reading if you assume continuations precede their row — gave Brinson Partners
    the name "82 Devonshire Street Boston, MA 02109 Brinson Partners, Inc.".
    Continuations therefore attach backwards, to the holder already emitted.

    Leading lines seen before any holder are the exception: those genuinely are a
    wrapped name for the holder about to appear.

    Adds `is_group`, because group subtotals aggregate holders that may also be
    listed individually and would otherwise be double-counted downstream.
    """
    roles = list(table.roles)
    name_i = _role_index(roles, "holder_name")
    if name_i is None:
        name_i = _role_index(roles, "name")
    if name_i is None:
        return table

    value_idx = [
        i for i, r in enumerate(roles)
        if r.rsplit("_", 1)[0] in ("shares", "percent") or r in ("shares", "percent")
    ]
    if not value_idx:
        return table

    records: list[dict] = []
    buffer: list[str] = []
    section = ""

    def attach(lines: list[str]) -> None:
        """Give trailing continuation lines to the holder already emitted."""
        if not lines or not records:
            return
        records[-1]["extra"].extend(lines)

    for row in table.rows:
        cell = (row[name_i] if name_i < len(row) else "").strip()
        has_values = any((row[i] if i < len(row) else "").strip() for i in value_idx)

        if not has_values:
            if not cell:
                continue
            if _SECTION_LABEL.search(cell):
                attach(buffer)
                buffer = []
                section = cell.rstrip(": ").strip()
            else:
                buffer.append(cell)
            continue

        if records:
            attach(buffer)          # trailing lines belong to the previous holder
            lead: list[str] = []
        else:
            lead = buffer           # nothing emitted yet: a wrapped leading name
        buffer = []

        records.append({
            "lead": lead,
            "cell": cell,
            "extra": [],
            "section": section,
            "rest": [(row[i] if i < len(row) else "") for i in range(len(roles)) if i != name_i],
        })

    attach(buffer)

    if not records:
        return table

    out_rows: list[list[str]] = []
    for rec in records:
        # Extra lines run name-continuation first, then address. The switch is the
        # first line that reads as an address: "Melville Corporation and
        # Subsidiaries / Employee Stock Ownership Plan Trust / 48 Wall Street"
        # is two name lines and one address line, not three of either.
        name_bits = [*rec["lead"], rec["cell"]]
        addr_bits: list[str] = []
        in_address = False
        for line in rec["extra"]:
            if not in_address and looks_like_address(line):
                in_address = True
            (addr_bits if in_address else name_bits).append(line)

        name, inline_addr = _split_holder_address(" ".join(b for b in name_bits if b))
        address = " ".join([inline_addr, *addr_bits]).strip()
        out_rows.append(
            [name, address, rec["section"], "1" if looks_like_group_row(name) else "0", *rec["rest"]]
        )

    out_roles = ["holder_name", "holder_address", "section", "is_group"] + [
        r for i, r in enumerate(roles) if i != name_i
    ]
    out_header = ["Holder", "Address", "Section", "Is Group"] + [
        (table.header[i] if i < len(table.header) else "")
        for i in range(len(roles)) if i != name_i
    ]
    return Table(header=out_header, rows=out_rows, roles=out_roles)


_STRATEGIES = {
    Assembly.PERSON_YEAR: assemble_people,
    Assembly.HOLDER: assemble_holders,
    Assembly.PLAIN: lambda t: t,
}


def clean(table: Table, assembly: Assembly = Assembly.PERSON_YEAR) -> Table:
    """Apply the shape-independent cleanups, then the profile's assembly."""
    t = merge_marker_columns(table)
    t = drop_marker_columns(t)
    t = drop_empty_value_columns(t)
    t = repair_roles_by_values(t)
    t = drop_blank_rows(t)
    return _STRATEGIES[assembly](t)
